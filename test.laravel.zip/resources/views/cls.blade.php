<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="{{url('/css/cls.css')}}">
    <script src="{{url('/js/cls.js')}}"></script>



    <title>Classifier</title>

</head>
<body>
    <h1>hi anya</h1>
    <input type="text" id="main-input" placeholder="СЛЫШИШЬ ВВОДИ">
    <table>
        <tr>
            <th>Фильмы</th>
            <th>Аниме</th>
            <th>Игры</th>
        </tr>
        <tr>
            <td>1</td>
            <td>2</td>
            <td>3</td>
        </tr>
        <tr>
            <td>1</td>
            <td>2</td>
            <td>3</td>
        </tr>
    </table>
</body>
</html>

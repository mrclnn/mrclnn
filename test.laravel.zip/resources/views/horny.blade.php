<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{url('/css/horny.css')}}">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="{{url('/js/horny.js')}}"></script>

{{--    <script src="{{url('/js/libs/masonry.js')}}"></script>--}}



    <title>Melancholy Eriscal</title>

</head>
<body>

<div id="controls">

    <h4 id="title">MEGUMIN<span id="titleCounter"></span></h4>
    <ul id="menu" class="hidden">
        @foreach($categories as $category)
        <li class="category" data-value="{{$category->dir_name}}" data-count="{{$category->max}}" data-current="0">{{$category->name}}</li>
        @endforeach
    </ul>
</div>
<div id="content">
    <img id="img" src="{{url('/img/0.jpg')}}" alt="">
</div>
<div id="like">
    <button data-value="0">DISLIKE</button>
    <button data-value="2">LIKE</button>
</div>
<p id="info"></p>

<script>


    var category = '';
    var current = 0;
    var max = 0;
    var body = document.querySelector('body');
    var categories = {};
    var picNames = [];
    document.querySelectorAll('.category').forEach(function(item){
        categories[item.dataset.value] = item;
    });

    body.onclick = function(e){

        if(e.target.closest('#controls')){
            // console.log('controls');
            ctrl(e.target);
        } else if(e.target.closest('#like')){
            estimate(e.target);
        } else {
            // console.log('img');
            slider(e);
        }



    }

    function ctrl(target){
        menu.classList.toggle('hidden');
        content.classList.toggle('hidden');
        if(target.classList.contains('category')){

            current = target.dataset.current;
            category = target.dataset.value;
            max = target.dataset.count;
            name = target.innerHTML;
            // console.log(name);

            sendRequest({get : category}, function(answ){
                picNames = answ;
                setImg(current);
            })
            img.setAttribute('src', '/img/loading.jpg');


            setTitle(name);
            setCounter(current, max);

        }
    }
    function slider(e){
        // console.log(e.offsetX);
        // console.log(innerWidth);
        if(max === 0) return;
        if(e.offsetX > innerWidth/2){
            if(++current > max) current = max;
            setImg(current);
            setCounter(current, max);
        } else {
            if(--current < 0) current = 0;
            setImg(current);
            setCounter(current, max);
        }
    }
    function estimate(target){
        sendRequest({estimate : target.dataset.value, post : picNames[current]}, function(answ){
            console.log(answ);
        })
        if(target.dataset.value === '0'){
            picNames.splice(current, 1);
            setImg(current);
        }
    }
    function setTitle(name){
        title.innerHTML = name + '<span id="titleCounter"></span>';
    }
    function setCounter(current, max){
        titleCounter.innerHTML = current + 1 + '/' + max;
        categories[category].dataset.current = current;
    }
    function setImg(current){
        img.setAttribute('src', '/img/' + picNames[current].file_name);
    }

    function sendRequest(query, callback){
        query._token = $('meta[name="csrf-token"]').attr('content');

        $.ajax({
            type : 'POST',
            url : '/ajax',
            data : query,
            // processData : false,
            dataType : 'JSON',
            success : function(data){
                console.log('success ajax lol');
                // console.log(data);
                callback(data);
            },
            error : function(err){
                console.log('error ajax lol');
                callback(err.responseText);
            }
        });
    }


</script>

</body>
</html>

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HornyCategories extends Model
{
    public $timestamps = false;
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_types extends Model
{
    public $timestamps = false;
}

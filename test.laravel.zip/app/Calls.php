<?php


namespace App;


use Illuminate\Database\Eloquent\Model;

class Calls extends Model
{
    public $connection = '';
}
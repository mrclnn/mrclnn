<?php

namespace App\Http\Controllers;



use App\HornyPosts;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AjaxController extends Controller
{
    public function execute(Request $request){
        $query = $request->all();
        $answer = [];
        if(isset($query['get'])){
            if($query['get'] === 'all'){
                $answer = DB::select('SELECT
file_name

FROM horny_posts
WHERE status IN (1,2)
ORDER BY RAND()');
            } else if($query['get'] === 'favorites'){
                $answer = DB::select('SELECT
file_name

FROM horny_posts
WHERE status = 2
ORDER BY RAND()');
            } else {
                $answer = DB::select('SELECT
file_name

FROM horny_posts
JOIN horny_categories hc on horny_posts.category_id = hc.id AND hc.dir_name = ?
WHERE status IN (1,2)
ORDER BY RAND()', [$query['get']]);
            }

        } else if(isset($query['estimate'])){
            $answer = DB::table('horny_posts')->where('file_name', $query['post'])->update(['status' => $query['estimate']]);
        }

        return response(json_encode($answer));
    }
}

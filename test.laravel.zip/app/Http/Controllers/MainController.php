<?php

namespace App\Http\Controllers;

use App\Categories;
use App\Product_types;
use App\HornyPosts;
use Illuminate\Http\Request;

class MainController extends Controller
{
    public function execute(Request $request){


        echo '<h1 align="center">Здравствуйте Тимур</h1>';
        die;



        $products = HornyPosts::all();
        $categories = Categories::all();
        $productsTypes = Product_types::all();

        $currentCategory = $request->category ?: '';
        $currentType = $request->type ?: '';

        return view('main', compact('products', 'categories', 'productsTypes', 'currentCategory', 'currentType'));
    }
}

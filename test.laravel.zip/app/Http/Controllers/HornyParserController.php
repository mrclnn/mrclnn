<?php

namespace App\Http\Controllers;

use App\HornyPosts;
use Illuminate\Http\Request;
use simplehtmldom\HtmlDocument;
use simplehtmldom\HtmlWeb;

class HornyParserController extends Controller
{
    private $tags_list = [
        're%3azero_kara_hajimeru_isekai_seikatsu',
        'tatsumaki',
        'megumin',
        'kaguya-sama_wa_kokurasetai_~tensai-tachi_no_renai_zunousen~',
        'matoi_ryuuko',
        'holo',
        'nia_teppelin',
        'suzumiya_haruhi',
        'yorha_2b',
        'zero_two_%28darling_in_the_franxx%29',
        'tsuki_wani',
        'sakura_haruno'
    ];
    private $fileName = 1;
    private $doc;
    private $tag;
    private $dirName;
    public function execute(Request $request){
        $this->doc = new HtmlWeb();
//
//        $res = (HornyCategories::all())->toArray();
//        var_dump($res->toArray());
        $cats = [
//            1 => 'megumin',
//            2 => 'tatsumaki',
//            3 => '2B',
//            4 => 'haruhi',
//            5 => 'holo',
//            6 => 'kaguya',
            7 => 'ryuuko',
            8 => 'monogatari',
            9 => 'nia_teppelin',
            10 => 'rezero',
            11 => 'sakura',
            12 => 'zero_two'
        ];


//        foreach ($cats as $id => $cat) {
//            $res = scandir("D:\pr\OpenServer\domains\\test.laravel\public/img/{$cat}/");
//            unset($res[0]);
//            unset($res[1]);
//            foreach($res as $fileName){
//                HornyPosts::create(['category_id' => $id, 'file_name' => "{$cat}/{$fileName}"]);
//            }
//        }

        die;

        $this->tag = 'sakura_haruno';
        $this->dirName = "D:\pr\OpenServer\domains\\test.laravel\public/img/{$this->tag}/";

        $this->parse($this->tag);



    }

    private function getLinks($tag, $pid){

        $url = 'https://rule34.xxx/index.php?page=post&s=list&tags=' . $tag . '&pid=' . $pid;
        $page = $this->doc->load($url);
        if($page !== null){
            $links = '';
            foreach($page->find('span.thumb') as $post){

                $url = $post->find('a', 0)->href;
                $id = preg_replace('/\D/', '', $url);
//            var_dump($id);
                $post = $this->doc->load('https://rule34.xxx/index.php?page=post&s=view&id=' . $id);
                $src = $post->find('img#image', 0);
                if($src){
                    $src = $src->attr['data-cfsrc'];
                } else {
//                var_dump('deleted post');
                    continue;
                }
                $links .= $src . ' ';
            }
        }
        return (object)[
            'links' => trim($links) ?: null,
            'pid' => $this->getPid($page)
        ];
    }

    private function getPid($page):string
    {
        $pagination = $page->find('div.pagination', 0);
        $next_page = $pagination->find('a[alt=next]', 0);
        if(empty($next_page)){
            return '-1';
        }
        $href = $next_page->href;
        return substr($href, strpos($href, '&pid='));
}

    private function parse(string $tag, string $pid = '0'){
        //        echo 'HORNY PARSER';

        $url = 'https://rule34.xxx/index.php?page=post&s=list&tags=' . $tag . '&pid=' . $pid;
        $i = 0;
        do{
            $page = $this->doc->load($url);
            if($page === null){
                echo 'не удалось загрузить сайт';
            }

            $this->get_contents($page);


            $pagination = $page->find('div.pagination', 0);
            $next_page = $pagination->find('a[alt=next]', 0);
            if(empty($next_page)){
                echo 'not found next page';
                break;
            }
            $href = $next_page->href;
            $pid = substr($href, strpos($href, '&pid='));
            $url = preg_replace('/&pid=\d+/', $pid, $url);
            $i++;
        }while($i < 50);

        echo 'END';
    }

    private function get_contents(HtmlDocument $page){

//        $dirName = storage_path()."/horny_parser/{$this->tag}/";
        var_dump($this->dirName);
        if(!file_exists($this->dirName)){
            if (!mkdir($this->dirName) && !is_dir($this->dirName)) {
                throw new \RuntimeException(sprintf('Directory "%s" was not created', $this->dirName));
            }
        }

        foreach($page->find('span.thumb') as $post){

            $url = $post->find('a', 0)->href;
            $id = preg_replace('/\D/', '', $url);
//            var_dump($id);
            $post = $this->doc->load('https://rule34.xxx/index.php?page=post&s=view&id=' . $id);
            $src = $post->find('img#image', 0);
            if($src){
                $src = $src->attr['data-cfsrc'];
            } else {
//                var_dump('deleted post');
                continue;
            }
//            echo $src . ',';
            $fileName = $this->dirName . $this->fileName++ . '.jpg';

            if(file_exists($fileName)){
                echo 'already exists' . '<br>';
                continue;
            }

            $image = $this->file_get_contents_curl($src);
            $success = file_put_contents($fileName, $image);

            var_dump(!!$success);

        }

    }

    private function file_get_contents_curl( $url ) {

        $ch = curl_init();

        curl_setopt( $ch, CURLOPT_AUTOREFERER, TRUE );
        curl_setopt( $ch, CURLOPT_HEADER, 0 );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, TRUE );

        $data = curl_exec( $ch );
        curl_close( $ch );

        return $data;

    }

    private function download(string $tag)
    {

    }

}

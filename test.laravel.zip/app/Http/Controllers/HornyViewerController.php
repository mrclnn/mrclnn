<?php

namespace App\Http\Controllers;

use App\HornyPosts;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HornyViewerController extends Controller
{
    public function execute(){

        $categories = DB::select('SELECT
horny_categories.id,
horny_categories.name,
count(horny_posts.id) as max,
horny_categories.dir_name

FROM horny_categories
JOIN horny_posts ON horny_categories.id = horny_posts.category_id
GROUP BY horny_categories.id');
        $favoritesCount = DB::select('SELECT
count(*) as count

FROM horny_posts
WHERE status = 2')[0]->count;

        $allCount = 0;
        foreach ($categories as $category) {
            $allCount += $category->max;
        }
        array_unshift($categories, (object)[
            'id' => 0,
            'name' => 'favorites',
            'max' => $favoritesCount,
            'dir_name' => 'favorites'
        ]);
        array_unshift($categories, (object)[
            'id' => 0,
            'name' => 'all',
            'max' => $allCount,
            'dir_name' => 'all'
        ]);
        return view('horny', ['categories' => $categories]);
    }
}

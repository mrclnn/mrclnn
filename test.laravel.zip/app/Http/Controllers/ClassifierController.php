<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClassifierController extends Controller
{
    public function execute(){

        return view('cls');

    }
}

<?php

namespace App\Jobs;

use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class TestJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $step = 0;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($step = 0)
    {
        $this->step = $step;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $step = $this->step;
        info('job, step = ' . $step);
        if($step < 5){
            $step++;
            self::dispatch($step)->delay(Carbon::now()->addSeconds(5));
        }
    }
}

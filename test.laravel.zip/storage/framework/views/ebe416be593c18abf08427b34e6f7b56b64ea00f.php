<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(url('/css/main.css')); ?>">
        <script src="<?php echo e(url('/js/main.js')); ?>"></script>

        <title>Melancholy Eriscal</title>

    </head>
    <body>
        <header>
            <h1>Melancholy Eriscal</h1>
        </header>
        <div class="wrapper clearfix">
            <aside id="category_nav">
                <ul id="category_list" class="nav_list">
                    <li class="category_item nav_item"><a href="">category item</a></li>
                    <li class="category_item nav_item"><a href>category item</a></li>
                    <li class="category_item nav_item"><a href>category item</a></li>
                    <li class="category_item nav_item"><a href>category item</a></li>
                    <li class="category_item nav_item"><a href>category item</a></li>
                    <li class="category_item nav_item"><a href>category item</a></li>
                    <li class="category_item nav_item"><a href>category item</a></li>
                </ul>
            </aside>
            <main>
                <nav id="product_nav">
                    <ul id="product_list" class="nav_list">
                        <li class="product_item nav_item"><a href="">product item</a></li>
                        <li class="product_item nav_item"><a href="">product item</a></li>
                        <li class="product_item nav_item"><a href="">product item</a></li>
                        <li class="product_item nav_item"><a href="">product item</a></li>
                        <li class="product_item nav_item"><a href="">product item</a></li>
                        <li class="product_item nav_item"><a href="">product item</a></li>
                        <li class="product_item nav_item"><a href="">product item</a></li>
                    </ul>
                </nav>
                <div id="product_container">
                    <div class="product">
                        <div class="product_poster"></div>
                    </div>
                    <div class="product">
                        <div class="product_poster"></div>
                    </div>
                    <div class="product">
                        <div class="product_poster"></div>
                    </div>
                    <div class="product">
                        <div class="product_poster"></div>
                    </div>
                    <div class="product">
                        <div class="product_poster"></div>
                    </div>
                    <div class="product">
                        <div class="product_poster"></div>
                    </div>
                    <div class="product">
                        <div class="product_poster"></div>
                    </div>
                </div>
            </main>
        </div>
        <footer>
            <p>This is footer</p>
        </footer>
    </body>
</html>
